import React from "react";
import './PharmaForm.css';
class PharmaForm extends React.Component {
    constructor() {
        super();
        this.state = {
            fields: {},
            errors: {}
        }
        this.handleChange = this.handleChange.bind(this);
        this.submituserRegistrationForm = this.submituserRegistrationForm.bind(this);
    };
    handleChange(e) {
        let fields = this.state.fields;
        fields[e.target.name] = e.target.value;
        this.setState({
            fields
        });
    }
    submituserRegistrationForm(e) {
        e.preventDefault();
        if (this.validateForm()) {
            alert("form submited succesfully");
        }
    }
   
    validateForm() {
        let fields = this.state.fields;
        let fvalid = true;
        let errors = {};

        if (!fields["name"]) {
            fvalid = false;
            errors["name"] = "*Please enter your Name.";
        }
        if (!fields["vid"]) {
            fvalid = false;
            errors["vid"] = "*Please enter your Vendor ID.";
        }
        if (!fields["address"]) {
            fvalid = false;
            errors["address"] = "*Please enter your Address.";
        }
        if (!fields["phno"]) {
            fvalid = false;
            errors["phno"] = "*Please enter your mobile no.";
        }
        if (!fields["password"]) {
            fvalid = false;
            errors["password"] = "*Please enter your password.";
        }
        if (!fields["cpassword"]) {
            fvalid = false;
            errors["cpassword"] = "*Please re-enter your password.";
        }
        this.setState({
            errors: errors
        });
        return fvalid;
    }
    render() {
        return (
            <table id="table" cellSpacing={2}>
                <tr>
                    <td align="center">
                        <div id="main-registration-container">
                            <div id="register">
                                <form method="post" name="userRegistrationForm" onSubmit={this.submituserRegistrationForm}>
                                    <h3>Register New Vendor</h3>
                                    <input type="text" name="name" placeholder="Enter Name" value={this.state.fields.username} onChange={this.handleChange} />
                                    <div className="errorMsg">{this.state.errors.name}</div>
                                    <input type="text" name="phno" placeholder="Enter Phone number" value={this.state.fields.mobileno} onChange={this.handleChange} />
                                    <div className="errorMsg">{this.state.errors.phno}</div>
                                    <input type="text" name="address" placeholder="Enter Address" value={this.state.fields.address} onChange={this.handleChange} />
                                    <div className="errorMsg">{this.state.errors.address}</div>
                                    <input type="text" name="vid" placeholder="Enter Vendor ID" value={this.state.fields.vendorid} onChange={this.handleChange} />
                                    <div className="errorMsg">{this.state.errors.vid}</div>
                                    <input type="password" name="password" placeholder="Enter Password" value={this.state.fields.password} onChange={this.handleChange} />
                                    <div className="errorMsg">{this.state.errors.password}</div>
                                    <input type="password" name="cpassword" placeholder="Retype Password" value={this.state.fields.retypepassword} onChange={this.handleChange} />
                                    <div className="errorMsg">{this.state.errors.cpassword}</div>
                                    <input type="submit" className="button" value="Submit" />
                                </form>
                            </div>
                        </div>
                    </td>
                    <td align="center">
                        <img src="pharma.png" className="images" />
                    </td>
                </tr>
            </table>
        );
    }
    
}

export default PharmaForm;