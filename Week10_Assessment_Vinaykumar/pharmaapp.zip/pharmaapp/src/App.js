import logo from './logo.svg';
import './App.css';
import PharmaForm from './PharmaForm';

function App() {
  return (
    <div className="App">
     <PharmaForm/>
    </div>
  );
}

export default App;
