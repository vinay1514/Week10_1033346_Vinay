import logo from './logo.svg';
import './App.css';
import LoadingComponent from './LoadingComponent';

function App() {
  return (
   <div>
      <LoadingComponent/>

    </div>
      );
}

export default App;
