import React from "react";
import './Loading.css';
 
function LoadingComponent(){
    return(
        <div className="screen1" >
            <div className="react">
                <img src="react.png" alt="React"height={50} width={50}/>
            </div>
            <div className="font">
                <p className="fontline">LOADING</p>
                <p className="fontline">SCREEN</p>
                <p className="fontline">REACTJS</p>
            </div>
        </div>
       
    );
}
 
export default LoadingComponent